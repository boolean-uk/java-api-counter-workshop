package com.example.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class JokeMachineControllerTest {

    @Test
    public void Test1() {
        JokeMachineController jokeMachineController = new JokeMachineController();
        jokeMachineController.random.setSeed(100);
        Assertions.assertEquals("What sort of car an egg drive? - A yolkswagen!!!", jokeMachineController.getJoke());
    }
}
