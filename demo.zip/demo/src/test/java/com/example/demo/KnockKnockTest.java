package com.example.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class KnockKnockTest {

    @Test
    public void getTheJoke() {
        KnockKnockController controller = new KnockKnockController();

        String result1 = controller.getTheJoke(1);
        Assertions.assertEquals("Knock, knock", result1);

        String result2 = controller.getTheJoke(2);
        Assertions.assertEquals("Knock, knock -> Who's there?", result2);

        // It works for the "Atch". I could test all the elements of the hashmap
//        controller.rand.setSeed(100);
//        String result3 = controller.getTheJoke(3);
//        Assertions.assertEquals("Knock, knock -> Who's there? -> Atch", result3);
//
//        String result4 = controller.getTheJoke(4);
//        Assertions.assertEquals("Knock, knock -> Who's there? -> Atch -> Atch who?", result4);
//
//        String result5 = controller.getTheJoke(5);
//        Assertions.assertEquals("Knock, knock -> Who's there? -> Atch -> Atch who? -> Bless you!", result5);
    }
}
