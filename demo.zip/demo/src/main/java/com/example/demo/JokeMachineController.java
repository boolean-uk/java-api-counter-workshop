package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

@RestController
@RequestMapping("/jokes")
public class JokeMachineController {
    private String[] jokes;
    Random random;

    public JokeMachineController() {
        jokes = new String[]{"What sort of car an egg drive? - A yolkswagen!!!",
                "What's orange and sounds like a parrot? A carrot!",
                "What do you call a fish with no eyes? Fsh.",
                "Why did the bicycle fall over? Because it was two-tired.",
                "I'm so good at sleeping; I can do it with my eyes closed."};
    }

    @GetMapping
    public String getJoke() {
        random = new Random();
        int rnd = random.nextInt(jokes.length);
        return jokes[rnd];
    }
}
