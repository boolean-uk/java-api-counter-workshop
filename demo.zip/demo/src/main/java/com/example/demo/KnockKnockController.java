package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

@RestController
@RequestMapping("/knock")
public class KnockKnockController {
    HashMap<String, String> answers = new HashMap<>();
    ArrayList<String> keys;
    ArrayList<String> str = new ArrayList<>();
    Random rand;
    ArrayList<String> previousLines = new ArrayList<>();

    public KnockKnockController() {
        answers.put("Lettuce", "Lettuce in, it's cold out here!");
        answers.put("Atch", "Bless you!");
        answers.put("Cow says", "No silly, cow says mooo!");
        answers.put("Harry", "Harry up and answer the door!");
        answers.put("Olive", "Olive you and I miss you!");
        answers.put("Justin", "Just in time for some more knock-knock jokes!");

        keys = new ArrayList<>(answers.keySet());
    }

    @GetMapping("/{line}")
    public String getTheJoke(@PathVariable int line) {
        String joke;

        rand = new Random();
        String randomKey = keys.get(rand.nextInt(answers.size()));

        switch (line) {
            case 1:
                previousLines.clear();
                joke = "Knock, knock";
                previousLines.add(joke);
                break;
            case 2:
                joke = "Who's there?";
                previousLines.add(joke);
                break;
            case 3:
                joke = randomKey;
                previousLines.add(joke);
                str.add(randomKey);
                break;
            case 4:
                joke = str.get(0) + " who?";
                previousLines.add(joke);
                break;
            case 5:
                joke = answers.get(str.get(0));
                previousLines.add(joke);
                str.clear();
                break;
        }
        return String.join(" -> ", previousLines);
    }
}
